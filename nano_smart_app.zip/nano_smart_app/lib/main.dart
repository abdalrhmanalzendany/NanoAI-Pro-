import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nano_smart_app/core/app/app.dart';
import 'package:nano_smart_app/core/di/di.dart';
import 'package:nano_smart_app/core/utils/logger.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize dependency injection
  await configureDependencies();

  // Set preferred orientations
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Log app start
  Logger.log('نانو الذكي - تم بدء التطبيق');

  runApp(const NanoSmartApp());
}


