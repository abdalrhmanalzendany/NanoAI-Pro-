class AppConstants {
  // App Info
  static const String appName = 'نانو الذكي';
  static const String appVersion = '1.0.0';
  static const String appDescription = 'مساعد ذكي تفاعلي مع مجسمات أنمي ثلاثية الأبعاد';

  // Animation Constants
  static const Duration defaultAnimationDuration = Duration(milliseconds: 300);
  static const Duration longAnimationDuration = Duration(milliseconds: 500);
  static const Duration shortAnimationDuration = Duration(milliseconds: 150);

  // Speech Constants
  static const Duration speechTimeoutDuration = Duration(seconds: 30);
  static const Duration speechPauseDuration = Duration(seconds: 3);

  // AI Constants
  static const int maxConversationHistory = 50;
  static const int maxResponseLength = 1000;

  // Character Constants
  static const List<String> availableCharacters = [
    'character_1',
    'character_2',
    'character_3',
  ];

  // Emotions
  static const List<String> availableEmotions = [
    'happy',
    'sad',
    'angry',
    'surprised',
    'neutral',
    'excited',
  ];

  // Storage Keys
  static const String userSettingsKey = 'user_settings';
  static const String conversationHistoryKey = 'conversation_history';
  static const String selectedCharacterKey = 'selected_character';
  static const String themeKey = 'theme_mode';
  static const String languageKey = 'language';

  // Default Values
  static const String defaultCharacter = 'character_1';
  static const String defaultEmotion = 'neutral';
  static const String defaultLanguage = 'ar';
}

