import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:nano_smart_app/core/di/di.dart';
import 'package:nano_smart_app/presentation/theme/app_theme.dart';
import 'package:nano_smart_app/presentation/pages/home/home_page.dart';
import 'package:nano_smart_app/presentation/blocs/speech/speech_bloc.dart';
import 'package:nano_smart_app/presentation/blocs/ai/ai_bloc.dart';
import 'package:nano_smart_app/presentation/blocs/animation/animation_bloc.dart';
import 'package:nano_smart_app/presentation/blocs/user/user_bloc.dart';
import 'package:nano_smart_app/presentation/blocs/assistant/assistant_bloc.dart';

class NanoSmartApp extends StatelessWidget {
  const NanoSmartApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<SpeechBloc>(
          create: (context) => getIt<SpeechBloc>(),
        ),
        BlocProvider<AiBloc>(
          create: (context) => getIt<AiBloc>(),
        ),
        BlocProvider<AnimationBloc>(
          create: (context) => getIt<AnimationBloc>(),
        ),
        BlocProvider<UserBloc>(
          create: (context) => getIt<UserBloc>(),
        ),
        BlocProvider<AssistantBloc>(
          create: (context) => getIt<AssistantBloc>(),
        ),
      ],
      child: MaterialApp(
        title: 'نانو الذكي',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        home: const HomePage(),
        locale: const Locale('ar', 'SA'),
        supportedLocales: const [
          Locale('ar', 'SA'),
          Locale('en', 'US'),
        ],
      ),
    );
  }
}

